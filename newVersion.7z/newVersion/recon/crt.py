#!/usr/bin/env python3
import requests
import json
import argparse
import re
import os



def banner():
    print(r"""
        .____          .__                        
    |    |    ____ |  |   ______ ____   ____  
    |    |   /  _ \|  |  /  ___// __ \_/ ___\ 
    |    |__(  <_> )  |__\___ \\  ___/\  \___ 
    |_______ \____/|____/____  >\___  >\___  >
            \/               \/     \/     \/ 

                Get Sub Domains
    """)


# دالة المساعدة
def help_message():
    print("""
Options:

-h     Help
-d     Search Domain Name       | Example: script.py -d hackerone.com
-o     Search Organization Name | Example: script.py -o hackerone+inc
""")


def clean_results(data_list):
    cleaned = set()
    for item in data_list:
        if item:
            item = item.replace('\\n', '\n')
            item = re.sub(r'\*\.', '', item)
            item = re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}', '', item)
            for line in item.splitlines():
                line = line.strip()
                if line:
                    cleaned.add(line)
    return sorted(cleaned)


def search_domain(domain):
    if not domain:
        print("Error: Domain name is required.")
        return

    url = f"https://crt.sh?q=%25.{domain}&output=json"
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64)"
    }
    response = requests.get(url, headers=headers)

    if not response.content:
        print(f"No results found for domain {domain}")
        return

    if "application/json" not in response.headers.get("Content-Type", ""):
        print("Error: Response is not JSON. Possibly blocked or unexpected format.")
        print(response.text[:300])
        return

    try:
        data = response.json()
    except json.JSONDecodeError:
        print("Error: Failed to parse JSON.")
        return

    values = []
    for entry in data:
        values.append(entry.get('common_name', ''))
        values.append(entry.get('name_value', ''))

    results = clean_results(values)

    if not results:
        print("No valid results found.")
        return

    os.makedirs("crt_domains", exist_ok=True)
    output_file = f"crt_domains/domain.{domain}.txt"
    with open(output_file, "w") as f:
        f.write('\n'.join(results))

    print()
    print('\n'.join(results))
    print()
    print(f"\033[32m[+]\033[0m Total Save will be \033[31m{len(results)}\033[0m Domain only")
    print(f"\033[32m[+]\033[0m Output saved in {output_file}")

def search_organization(org):
    if not org:
        print("Error: Organization name is required.")
        return

    url = f"https://crt.sh?q={org}&output=json"
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64)"
    }
    response = requests.get(url, headers=headers)

    if not response.content:
        print(f"No results found for organization {org}")
        return

    if "application/json" not in response.headers.get("Content-Type", ""):
        print("Error: Response is not JSON. Possibly blocked or unexpected format.")
        print(response.text[:300])
        return

    try:
        data = response.json()
    except json.JSONDecodeError:
        print("Error: Failed to parse JSON.")
        return

    values = [entry.get('common_name', '') for entry in data]
    results = clean_results(values)

    if not results:
        print("No valid results found.")
        return

    os.makedirs("crt_domains", exist_ok=True)
    output_file = f"crt_domains/org.{org}.txt"
    with open(output_file, "w") as f:
        f.write('\n'.join(results))

    print()
    print('\n'.join(results))
    print()
    print(f"\033[32m[+]\033[0m Total Save will be \033[31m{len(results)}\033[0m Domain only")
    print(f"\033[32m[+]\033[0m Output saved in {output_file}")


def main():
    banner()
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-h", action="store_true")
    parser.add_argument("-d", type=str)
    parser.add_argument("-o", type=str)
    args = parser.parse_args()

    if args.h or (not args.d and not args.o):
        help_message()
    elif args.d:
        search_domain(args.d)
    elif args.o:
        search_organization(args.o)



if __name__ == "__main__":
    main()
