#!/bin/bash
# Recon Workflow Script

set -e

if [ $# -lt 1 ]; then
    echo "Usage: $0 target.com"
    exit 1
fi

TARGET=$1
OUTDIR="recon_results"
SUBDIR="$OUTDIR/subs"
URLDIR="$OUTDIR/urls"

mkdir -p "$SUBDIR" "$URLDIR"

echo "[*] Running Subfinder..."
subfinder -d $TARGET -silent > "$SUBDIR/subfinder.txt"

echo "[*] Running Amass..."
amass enum -passive -d $TARGET -o "$SUBDIR/amass.txt"

echo "[*] Running crt.py..."
python3 crt.py -d $TARGET > "$SUBDIR/crt.txt"

echo "[*] Combining all subdomains..."
cat "$SUBDIR/"*.txt | sort -u > "$OUTDIR/all_subs.txt"
echo "[+] Total subdomains found: $(wc -l < $OUTDIR/all_subs.txt)"

echo "[*] Running httpx.py..."
python3 httpx.py -w "$OUTDIR/all_subs.txt"

if [ ! -f "httpx_sc/2xx_success.txt" ]; then
    echo "[-] httpx_sc/2xx_success.txt not found! Did httpx.py run correctly?"
    exit 1
fi

cp httpx_sc/2xx_success.txt "$OUTDIR/alive.txt"
echo "[+] Alive domains: $(wc -l < $OUTDIR/alive.txt)"

echo "[*] Running gau on alive domains..."
cat "$OUTDIR/alive.txt" | gau > "$URLDIR/urls_raw.txt"

echo "[*] Cleaning URLs with uro..."
cat "$URLDIR/urls_raw.txt" | uro > "$URLDIR/urls_clean.txt"
echo "[+] Clean URLs: $(wc -l < $URLDIR/urls_clean.txt)"

echo "[*] Running gf patterns..."
cat "$URLDIR/urls_clean.txt" | gf lfi > "$URLDIR/gf_lfi.txt"
cat "$URLDIR/urls_clean.txt" | gf ssrf > "$URLDIR/gf_ssrf.txt"
cat "$URLDIR/urls_clean.txt" | gf redirect > "$URLDIR/gf_redirect.txt"

echo "[+] LFI candidates: $(wc -l < $URLDIR/gf_lfi.txt)"
echo "[+] SSRF candidates: $(wc -l < $URLDIR/gf_ssrf.txt)"
echo "[+] Redirect candidates: $(wc -l < $URLDIR/gf_redirect.txt)"

echo "✅ Recon finished! Results saved in $OUTDIR"
