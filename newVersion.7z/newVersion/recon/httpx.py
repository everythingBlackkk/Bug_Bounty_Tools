import argparse
import requests
import os
from concurrent.futures import ThreadPoolExecutor
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

# Create results directory and files
def create_result_files():
    if not os.path.exists("httpx_sc"):
        os.makedirs("httpx_sc")
    
    # Clear existing files
    open("httpx_sc/2xx_success.txt", "w").close()
    open("httpx_sc/3xx_redirect.txt", "w").close()
    open("httpx_sc/4xx_client_error.txt", "w").close()

# Save result to appropriate file
def save_result(url, status_code):
    if 200 <= status_code < 300:
        with open("httpx_sc/2xx_success.txt", "a") as f:
            f.write(f"{url}\n")
    elif 300 <= status_code < 400:
        with open("httpx_sc/3xx_redirect.txt", "a") as f:
            f.write(f"{url}\n")
    elif 400 <= status_code < 500:
        with open("httpx_sc/4xx_client_error.txt", "a") as f:
            f.write(f"{url}\n")


# Get color based on status code
def get_color(status_code):
    if 200 <= status_code < 300:
        return Fore.GREEN
    elif 300 <= status_code < 400:
        return Fore.BLUE
    elif 400 <= status_code < 500:
        return Fore.YELLOW
    elif 500 <= status_code < 600:
        return Fore.RED
    else:
        return Fore.WHITE

# Try HTTPS first, then HTTP if needed
def check_url(domain, status_filter):
    domain = domain.strip()
    for scheme in ["https://", "http://"]:
        url = scheme + domain if not domain.startswith("http") else domain
        try:
            response = requests.get(url, timeout=10)
            status = response.status_code
            color = get_color(status)
            
            # Save result to file
            save_result(url, status)
            
            if status_filter:
                if status == status_filter:
                    print(f"{color}[{status}] {url}")
            else:
                print(f"{color}[{status}] {url}")
            return  # Success, no need to try second scheme
        except requests.RequestException:
            continue
    # If both HTTP and HTTPS fail
    print(f"{Fore.MAGENTA}[ERROR] Failed to connect -> {domain}")

# Main function
def main():
    parser = argparse.ArgumentParser(description="Check HTTP status codes for a list of domains.")
    parser.add_argument("-w", "--wordlist", required=True, help="Path to the file containing domain names.")
    parser.add_argument("-sc", "--status-code", type=int, help="Filter by specific status code (e.g., 200)")
    args = parser.parse_args()

    try:
        with open(args.wordlist, "r") as f:
            domains = f.readlines()
    except FileNotFoundError:
        print(Fore.RED + f"[!] File not found: {args.wordlist}")
        return

    # Create result files
    create_result_files()

    print(Style.BRIGHT + f"\n[*] Scanning {len(domains)} domains...\n")

    with ThreadPoolExecutor(max_workers=30) as executor:
        for domain in domains:
            executor.submit(check_url, domain, args.status_code)

if __name__ == "__main__":
    main()