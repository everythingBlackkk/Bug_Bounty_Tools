#!/usr/bin/env python3
import requests
import argparse
import sys

def banner():
    print(r"""
        .____          .__                        
        |    |    ____ |  |   ______ ____   ____  
        |    |   /  _ \|  |  /  ___// __ \_/ ___\ 
        |    |__(  <_> )  |__\___ \\  ___/\  \___ 
        |_______ \____/|____/____  >\___  >\___  >
                \/               \/     \/     \/ 

                [+] everythingBlackkk      
                [+] Yassin Mohamed
                [+] CORS vulnerability 
          
    """)
# Different payloads to test
def generate_origins(domain):
    return [
        "http://evil.com",
        "https://evil.com",
        f"http://blabla.{domain}",
        f"https://blabla.{domain}",
        f"http://{domain}.blabla.com",
        f"https://{domain}.blabla.com",
        f"http://{domain}blabla.com",
        f"https://{domain}blabla.com",
    ]

def test_cors(domain):
    print(f"\n[+] Testing: {domain}")
    test_urls = [f"http://{domain}", f"https://{domain}"]

    for url in test_urls:
        for origin in generate_origins(domain):
            try:
                headers = {"Origin": origin}
                response = requests.get(url, headers=headers, timeout=5, verify=False)

                acao = response.headers.get("Access-Control-Allow-Origin") 
                acc = response.headers.get("Access-Control-Allow-Credentials") # 

                if acao:
                    # Exact match with injected origin
                    if acao == origin:
                        print(f"[!] Potential CORS vulnerability detected!")
                        print(f"    URL: {url}")
                        print(f"    Origin: {origin}")
                        print(f"    Response Header: Access-Control-Allow-Origin: {acao}")
                        if acc:
                            print(f"    Access-Control-Allow-Credentials: {acc}")

                    # Wildcard check
                    elif acao == "*":
                        print(f"[!] Wildcard ACAO detected!")
                        print(f"    URL: {url}")
                        print(f"    Origin tried: {origin}")
                        print(f"    Response Header: Access-Control-Allow-Origin: *")
                        if acc:
                            print(f"    Access-Control-Allow-Credentials: {acc}")

                    # Null check
                    elif acao.lower() == "null":
                        print(f"[!] Null ACAO detected!")
                        print(f"    URL: {url}")
                        print(f"    Origin tried: {origin}")
                        print(f"    Response Header: Access-Control-Allow-Origin: null")
                        if acc:
                            print(f"    Access-Control-Allow-Credentials: {acc}")

            except requests.RequestException:
                pass  # Ignore connection errors

def main():
    banner()
    parser = argparse.ArgumentParser(description="CORS Misconfiguration Scanner")
    parser.add_argument("-d", "--domain", help="Single domain to test (e.g. example.com)")
    parser.add_argument("-l", "--list", help="File containing list of domains")

    args = parser.parse_args()

    if not args.domain and not args.list:
        print("Usage:")
        print("  python3 cors.py -d example.com")
        print("  python3 cors.py -l domains.txt")
        sys.exit(1)

    domains = []
    if args.domain:
        domains.append(args.domain.strip())
    if args.list:
        with open(args.list, "r") as f:
            domains.extend([line.strip() for line in f if line.strip()])

    for domain in domains:
        test_cors(domain)

if __name__ == "__main__":
    requests.packages.urllib3.disable_warnings()
    main()
