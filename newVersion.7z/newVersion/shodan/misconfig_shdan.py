#!/usr/bin/env python3
import argparse
import shodan
import sys
import socket
import time
import os
from datetime import datetime

SHODAN_API_KEY = "lol"

PANELS = {
    "phpMyAdmin": 'http.title:"phpMyAdmin"',
    "Jenkins": 'http.title:"Dashboard [Jenkins]"',
    "Kibana": 'http.title:"Kibana"',
    "GitLab": 'http.title:"Sign in · GitLab"',
    "Tomcat": 'http.title:"Apache Tomcat"',
    "Admin Panels": 'http.title:"Admin" OR http.title:"Login"',
    "Open Directories": 'http.title:"Index of /"',
    "Elasticsearch": 'port:9200 "_cluster"',
    "MongoDB": 'port:27017 "MongoDB Server Information"',
    "Redis": '"Redis server"',
    "MySQL": 'port:3306 "mysql_native_password"',
    "Prometheus": 'http.title:"Prometheus Time Series Collection and Processing Server"',
    "Grafana": 'http.title:"Grafana"',
    "SonarQube": 'http.title:"SonarQube"',
    "Jira": 'http.title:"Log in - Jira"',
    "Confluence": 'http.title:"Log in - Confluence"',
    "Bitbucket": 'http.title:"Log in - Bitbucket"',
    "MinIO": 'http.title:"MinIO Browser"',
    "OwnCloud": 'http.title:"ownCloud"',
    "Nextcloud": 'http.title:"Nextcloud"',
    "Zabbix": 'http.title:"Zabbix"',
    "cPanel": 'http.title:"cPanel Login"',
    "Webmin": 'http.title:"Login to Webmin"',
    "Plesk": 'http.title:"Plesk"',
}

MISCONFIGS = {
    "SMTP Open Relay": 'port:25 "220" "relay"',
    "SMTP No Auth": 'port:25 "220" -"auth"',
    "SMTP Postfix": 'port:25 "Postfix"',
    "SMTP Sendmail": 'port:25 "Sendmail"',
    "FTP Anonymous": 'port:21 "230 Anonymous"',
    "FTP Welcome": 'port:21 "220"',
    "SSH Default": 'port:22 "SSH-2.0-OpenSSH" "root@"',
    "SSH Weak Ciphers": 'port:22 "aes128-cbc"',
    "Telnet Open": 'port:23 "login:"',
    "DNS Zone Transfer": 'port:53 "version.bind"',
    "SNMP Public": 'port:161 "public"',
    "SNMP Private": 'port:161 "private"',
    "RDP Open": 'port:3389 "Terminal Services"',
    "VNC Open": 'port:5900 "RFB"',
    "Docker API": 'port:2375 "Docker"',
    "Docker Registry": 'port:5000 "registry"',
    "Kubernetes API": 'port:6443 "kubernetes"',
    "Kubernetes Dashboard": 'port:8443 "kubernetes-dashboard"',
    "Memcached": 'port:11211 "stats"',
    "CouchDB": 'port:5984 "couchdb"',
    "Cassandra": 'port:9042 "cluster_name"',
    "Rsync": 'port:873 "rsync"',
    "NFS": 'port:2049 "nfs"',
    "SMB Open": 'port:445 "SMB"',
    "LDAP Anonymous": 'port:389 "dc="',
    "LDAP SSL": 'port:636 "dc="',
    "MSSQL": 'port:1433 "mssql"',
    "Oracle DB": 'port:1521 "oracle"',
    "PostgreSQL": 'port:5432 "PostgreSQL"',
    "Hadoop": 'port:50070 "hadoop"',
    "Apache Spark": 'port:4040 "spark"',
    "Jupyter Notebook": 'http.title:"Jupyter Notebook"',
    "RabbitMQ": 'port:15672 "rabbitmq"',
    "Apache Status": 'http.title:"Apache Status"',
    "Nginx Status": 'http.title:"nginx status"',
    "PHP Info": 'http.title:"phpinfo()"',
    "Server Status": '"server-status" "apache"',
    "Git Config": 'http.html:".git/config"',
    "Env Files": 'http.html:".env"',
    "Backup Files": 'http.html:"backup" "sql"',
    "Log Files": 'http.html:"error.log"',
}

def get_domain_ips(api, domain):
    try:
        query = f'hostname:"{domain}"'
        results = api.search(query, limit=1000)
        
        all_ips = set()
        
        for match in results['matches']:
            all_ips.add(match['ip_str'])
        
        return list(all_ips)
        
    except Exception as e:
        return []

def search_panels(api, domain):
    results = []
    
    for panel_name, panel_query in PANELS.items():
        try:
            query = f'({panel_query}) hostname:"{domain}"'
            res = api.search(query, limit=50)
            
            if res['matches']:
                for match in res['matches']:
                    ip = match.get('ip_str', 'N/A')
                    port = match.get('port', 'N/A')
                    hostnames = match.get('hostnames', [])
                    product = match.get('product', 'Unknown')
                    version = match.get('version', '')
                    
                    title = 'N/A'
                    if 'http' in match:
                        title = match['http'].get('title', 'N/A')
                    
                    hostname_str = ', '.join(hostnames) if hostnames else ip
                    result = f"[PANEL][{panel_name}] {hostname_str}:{port} | {product} {version} | {title}"
                    results.append(result)
                    
            time.sleep(0.3)
            
        except Exception as e:
            pass
    
    return results

def search_misconfigs(api, domain):
    results = []
    
    for misconfig_name, misconfig_query in MISCONFIGS.items():
        try:
            query = f'({misconfig_query}) hostname:"{domain}"'
            res = api.search(query, limit=50)
            
            if res['matches']:
                for match in res['matches']:
                    ip = match.get('ip_str', 'N/A')
                    port = match.get('port', 'N/A')
                    hostnames = match.get('hostnames', [])
                    product = match.get('product', 'Unknown')
                    version = match.get('version', '')
                    banner = match.get('data', '')[:100] + '...' if match.get('data') else 'N/A'
                    
                    hostname_str = ', '.join(hostnames) if hostnames else ip
                    result = f"[MISCONFIG][{misconfig_name}] {hostname_str}:{port} | {product} {version} | {banner}"
                    results.append(result)
                    
            time.sleep(0.3)
            
        except Exception as e:
            pass
    
    return results

def search_by_ips(api, ips, domain):
    results = []
    
    for ip in ips[:10]:
        try:
            for panel_name, panel_query in {**PANELS, **MISCONFIGS}.items():
                query = f'({panel_query}) ip:"{ip}"'
                res = api.search(query, limit=20)
                
                if res['matches']:
                    for match in res['matches']:
                        port = match.get('port', 'N/A')
                        hostnames = match.get('hostnames', [])
                        product = match.get('product', 'Unknown')
                        version = match.get('version', '')
                        
                        if panel_name in PANELS:
                            title = 'N/A'
                            if 'http' in match:
                                title = match['http'].get('title', 'N/A')
                            result = f"[IP-PANEL][{panel_name}] {ip}:{port} | {', '.join(hostnames)} | {product} {version} | {title}"
                        else:
                            banner = match.get('data', '')[:100] + '...' if match.get('data') else 'N/A'
                            result = f"[IP-MISCONFIG][{panel_name}] {ip}:{port} | {', '.join(hostnames)} | {product} {version} | {banner}"
                        
                        results.append(result)
                
                time.sleep(0.2)
                
        except Exception as e:
            pass
    
    return results

def scan_domain(api, domain, output_file):
    print(f"\n[*] Starting scan for: {domain}")
    print("=" * 50)
    
    all_results = []
    
    print("[*] Searching for panels...")
    panel_results = search_panels(api, domain)
    all_results.extend(panel_results)
    
    print("[*] Searching for misconfigurations...")
    misconfig_results = search_misconfigs(api, domain)
    all_results.extend(misconfig_results)
    
    print("[*] Getting domain IPs...")
    domain_ips = get_domain_ips(api, domain)
    if domain_ips:
        print(f"[+] Found {len(domain_ips)} IPs, scanning top 10...")
        ip_results = search_by_ips(api, domain_ips, domain)
        all_results.extend(ip_results)
    
    unique_results = list(set(all_results))
    
    if unique_results:
        print(f"\n[+] Found {len(unique_results)} issues for {domain}:")
        for result in unique_results:
            print(f"    {result}")
        
        with open(output_file, "a") as f:
            f.write(f"\n{'='*80}\n")
            f.write(f"DOMAIN: {domain}\n")
            f.write(f"SCAN TIME: {datetime.now()}\n")
            f.write(f"RESULTS: {len(unique_results)}\n")
            f.write(f"{'='*80}\n")
            for result in unique_results:
                f.write(result + "\n")
    else:
        print(f"[-] No issues found for {domain}")
        with open(output_file, "a") as f:
            f.write(f"\nDOMAIN: {domain} - No issues found\n")
    
    print(f"[✓] Completed scan for: {domain}")
    return len(unique_results)

def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-d", "--domain", help="Target domain")
    group.add_argument("-l", "--list", help="File with list of domains")
    args = parser.parse_args()
    
    if SHODAN_API_KEY == "YOUR_API_KEY_HERE":
        print("[!] Please set your Shodan API key")
        sys.exit(1)
    
    try:
        api = shodan.Shodan(SHODAN_API_KEY)
        api.info()
        print("[+] API key is valid")
    except Exception as e:
        print(f"[!] API Error: {e}")
        sys.exit(1)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"scan_results_{timestamp}.txt"
    
    with open(output_file, "w") as f:
        f.write("# Domain Security Scan Results\n")
        f.write(f"# Generated: {datetime.now()}\n")
        f.write(f"# Panels and Misconfigurations Scanner\n\n")
    
    domains = []
    total_issues = 0
    
    if args.domain:
        domains = [args.domain.strip()]
    elif args.list:
        try:
            with open(args.list, "r") as f:
                domains = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(f"[!] File {args.list} not found")
            sys.exit(1)
    
    print(f"[*] Starting scan of {len(domains)} domains")
    print(f"[*] Results will be saved to: {output_file}")
    
    for i, domain in enumerate(domains, 1):
        print(f"\n[*] Progress: {i}/{len(domains)}")
        issues_found = scan_domain(api, domain, output_file)
        total_issues += issues_found
        
        if i < len(domains):
            print("[*] Waiting 3 seconds before next domain...")
            time.sleep(3)
    
    print(f"\n{'='*80}")
    print(f"[+] SCAN COMPLETED")
    print(f"[+] Total domains scanned: {len(domains)}")
    print(f"[+] Total issues found: {total_issues}")
    print(f"[+] Results saved to: {output_file}")
    print(f"{'='*80}")

if __name__ == "__main__":
    main()